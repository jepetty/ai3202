# Assignment 8 - Hidden Markov Models
This repositiory contains Assignment 8 for CSCI 3202 - Artificial Intelligence. This assignment focuses on using Hidden Markov Models to discover typos in a text document.

## Running The Code
To run this code, simply run the command: "$ python3 HiddenMarkov.py" in the command line. Probabilities will be outputted to a text file: outputFile.txt.  
